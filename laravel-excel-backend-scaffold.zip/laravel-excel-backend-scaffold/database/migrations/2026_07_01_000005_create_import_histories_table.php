<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('import_histories', function (Blueprint $table) {
            $table->id();
            $table->string('file_name');
            $table->string('imported_by')->nullable();
            $table->timestamp('import_date')->nullable();
            $table->unsignedInteger('total_rows')->default(0);
            $table->unsignedInteger('success_rows')->default(0);
            $table->unsignedInteger('failed_rows')->default(0);
            $table->unsignedInteger('projects_added')->default(0);
            $table->unsignedInteger('projects_updated')->default(0);
            $table->unsignedInteger('activities_added')->default(0);
            $table->unsignedInteger('documents_added')->default(0);
            $table->string('status');
            $table->string('error_file_path')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('import_histories');
    }
};
