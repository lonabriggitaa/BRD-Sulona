<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string('brd_number')->unique();
            $table->string('project_name');
            $table->string('division');
            $table->string('department')->nullable();
            $table->string('site')->nullable();
            $table->string('category')->nullable();
            $table->string('priority')->nullable();
            $table->string('vendor')->nullable();
            $table->string('pic');
            $table->decimal('budget_requested', 18, 2)->nullable();
            $table->decimal('budget_approved', 18, 2)->default(0);
            $table->decimal('actual_cost', 18, 2)->nullable();
            $table->date('planned_start_date')->nullable();
            $table->date('planned_finish_date')->nullable();
            $table->date('actual_start_date')->nullable();
            $table->date('actual_finish_date')->nullable();
            $table->unsignedTinyInteger('progress')->default(0);
            $table->string('status');
            $table->string('health_status')->nullable();
            $table->text('remarks')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
