<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Import Update</title>
    <style>
        body { margin: 0; background: #f8fafc; color: #0f172a; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
        main { max-width: 1180px; margin: 0 auto; padding: 32px 20px 56px; }
        h1, h2, h3 { margin: 0; }
        p { color: #64748b; }
        .hero, .panel { border: 1px solid #dbe3ef; border-radius: 14px; background: white; box-shadow: 0 12px 28px rgba(15, 23, 42, .06); }
        .hero { padding: 22px; display: flex; justify-content: space-between; gap: 18px; flex-wrap: wrap; }
        .panel { margin-top: 18px; padding: 18px; }
        .toolbar, .cards, .steps { display: flex; gap: 10px; flex-wrap: wrap; }
        .button { min-height: 38px; border: 1px solid #dbe3ef; border-radius: 10px; background: white; color: #0f172a; padding: 0 14px; font-weight: 800; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; }
        .button.primary { background: #2563eb; border-color: #2563eb; color: white; }
        .button:disabled { opacity: .55; cursor: not-allowed; }
        .badge { display: inline-flex; align-items: center; border-radius: 999px; padding: 4px 10px; font-size: 12px; font-weight: 800; background: #eef2ff; color: #1d4ed8; }
        .badge.success { background: #dcfce7; color: #166534; }
        .badge.failed { background: #fee2e2; color: #991b1b; }
        .upload { border: 1px dashed #cbd5e1; border-radius: 12px; background: #f8fafc; padding: 24px; }
        .upload.dragover { border-color: #2563eb; background: #eff6ff; }
        .card, .step { flex: 1 1 160px; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px; background: #ffffff; }
        .card strong { display: block; font-size: 24px; margin-top: 8px; }
        .step span { display: inline-grid; place-items: center; width: 28px; height: 28px; border-radius: 999px; background: #e0f2fe; color: #0369a1; font-weight: 900; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; }
        th, td { border-bottom: 1px solid #e2e8f0; padding: 10px; text-align: left; font-size: 13px; vertical-align: top; }
        th { color: #475569; background: #f8fafc; }
        .muted { color: #64748b; }
        .toast { position: fixed; right: 18px; bottom: 18px; background: #0f172a; color: white; padding: 12px 14px; border-radius: 12px; box-shadow: 0 18px 40px rgba(15, 23, 42, .25); display: none; }
        .toast.show { display: block; }
    </style>
</head>
<body>
<main>
    <section class="hero">
        <div>
            <span class="badge">Excel Import</span>
            <h1>Import Update</h1>
            <p>Upload the latest Excel template to update investment dashboard data.</p>
            <p id="syncMeta" class="muted">Loading latest synchronization...</p>
        </div>
        <div class="toolbar">
            <a class="button" href="/api/import/template">Download Latest Template</a>
            <button class="button" type="button" id="previewButton">Preview Changes</button>
            <button class="button primary" type="button" id="importButton" disabled>Import Data</button>
            <button class="button" type="button" id="refreshButton">Refresh Dashboard</button>
        </div>
    </section>

    <section class="panel">
        <h2>Step Workflow</h2>
        <div class="steps" style="margin-top:12px">
            <div class="step"><span>1</span><h3>Download Template</h3><p>Use the approved workbook.</p></div>
            <div class="step"><span>2</span><h3>Update Excel</h3><p>Fill project, activity, and document rows.</p></div>
            <div class="step"><span>3</span><h3>Upload File</h3><p>Select one completed .xlsx file.</p></div>
            <div class="step"><span>4</span><h3>Preview Changes</h3><p>Review validation before import.</p></div>
            <div class="step"><span>5</span><h3>Import Data</h3><p>Save the validated rows.</p></div>
            <div class="step"><span>6</span><h3>Dashboard Updated</h3><p>Refresh the dashboard data.</p></div>
        </div>
    </section>

    <section class="panel">
        <h2>Upload File</h2>
        <div class="upload" id="dropZone">
            <input id="fileInput" type="file" accept=".xlsx">
            <p>Drag and drop Excel here, or browse a file. Accepted file type: <strong>.xlsx</strong>. Maximum size: <strong>20 MB</strong>.</p>
            <p id="fileName" class="muted">No file selected.</p>
        </div>
    </section>

    <section class="panel">
        <h2>Preview Changes</h2>
        <div class="cards" id="previewCards"></div>
        <div id="previewTable"><p class="muted">No file previewed yet.</p></div>
    </section>

    <section class="panel">
        <h2>Validation Result</h2>
        <div id="validationResult"><p class="muted">Upload and preview a file to see validation messages.</p></div>
    </section>

    <section class="panel">
        <h2>Import Summary</h2>
        <div id="importSummary"><p class="muted">No import has been processed.</p></div>
    </section>

    <section class="panel">
        <h2>Import History</h2>
        <div id="historyTable"><p class="muted">Loading import history...</p></div>
    </section>
</main>

<div class="toast" id="toast">Investment data synchronized successfully.</div>

<script>
let previewFilePath = "";
let previewIsValid = false;

const formatCurrency = (value) => new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
}).format(Number(value || 0)).replace(/\u00A0/g, ' ');

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    window.setTimeout(() => toast.classList.remove('show'), 3200);
}

function card(label, value) {
    return `<div class="card"><span class="muted">${label}</span><strong>${value}</strong></div>`;
}

function statusBadge(status) {
    const normalized = String(status || '').toLowerCase();
    const cls = normalized === 'success' ? 'success' : normalized === 'failed' ? 'failed' : '';
    return `<span class="badge ${cls}">${status || '-'}</span>`;
}

async function loadHistory() {
    const response = await fetch('/api/import/history');
    const json = await response.json();
    const rows = json.data?.data || [];
    const latest = json.latest;

    document.getElementById('syncMeta').textContent = latest
        ? `Last Sync: ${latest.import_date || '-'} | Status: ${latest.status || '-'} | Imported By: ${latest.imported_by || '-'}`
        : 'No import has been synchronized yet.';

    document.getElementById('historyTable').innerHTML = rows.length
        ? `<table><thead><tr><th>Import Date</th><th>File Name</th><th>Imported By</th><th>Projects Added</th><th>Projects Updated</th><th>Activities Added</th><th>Documents Added</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map(row => `<tr><td>${row.import_date || '-'}</td><td>${row.file_name}</td><td>${row.imported_by || '-'}</td><td>${row.projects_added || 0}</td><td>${row.projects_updated || 0}</td><td>${row.activities_added || 0}</td><td>${row.documents_added || 0}</td><td>${statusBadge(row.status)}</td><td>${row.error_file_path ? 'Download Log' : 'View'}</td></tr>`).join('')}</tbody></table>`
        : '<p class="muted">No import history yet.</p>';
}

async function refreshDashboardData() {
    const response = await fetch('/api/dashboard/summary');
    const json = await response.json();
    const kpis = json.kpis || {};
    document.getElementById('importSummary').innerHTML = `
        <div class="cards">
            ${card('Projects', kpis.total_projects || 0)}
            ${card('Activities', kpis.activity_count || 0)}
            ${card('Documents', kpis.document_count || 0)}
            ${card('Total Investment', formatCurrency(kpis.total_investment || 0))}
        </div>
    `;
}

function renderPreview(json) {
    const summary = json.summary || {};
    document.getElementById('previewCards').innerHTML = [
        card('New Projects', summary.new_projects || 0),
        card('Updated Projects', summary.updated_projects || 0),
        card('Activities Added', summary.activities_added || 0),
        card('Documents Added', summary.documents_added || 0),
        card('Rows with Errors', summary.rows_with_errors || 0),
    ].join('');

    const projectRows = (json.preview?.PROJECT_MASTER || []).slice(0, 8);
    document.getElementById('previewTable').innerHTML = projectRows.length
        ? `<table><thead><tr><th>BRD Number</th><th>Project Name</th><th>Division</th><th>Budget Approved</th><th>Status</th></tr></thead><tbody>${projectRows.map(row => `<tr><td>${row.brd_number || '-'}</td><td>${row.project_name || '-'}</td><td>${row.division || '-'}</td><td>${formatCurrency(row.budget_approved || 0)}</td><td>${row.status || '-'}</td></tr>`).join('')}</tbody></table>`
        : '<p class="muted">No project rows found.</p>';

    document.getElementById('validationResult').innerHTML = json.errors?.length
        ? `<table><thead><tr><th>Sheet Name</th><th>Row Number</th><th>Column Name</th><th>Error Message</th></tr></thead><tbody>${json.errors.map(error => `<tr><td>${error.sheet}</td><td>${error.row || '-'}</td><td>${error.column}</td><td>${error.message}</td></tr>`).join('')}</tbody></table>`
        : '<p>Validation passed. Import Data is available.</p>';

    previewFilePath = json.file_path || '';
    previewIsValid = Boolean(json.valid);
    document.getElementById('importButton').disabled = !previewIsValid || !previewFilePath;
}

async function previewFile() {
    const file = document.getElementById('fileInput').files[0];
    if (!file) return alert('Choose an Excel file first.');
    if (!file.name.toLowerCase().endsWith('.xlsx')) return alert('Only .xlsx files are accepted.');
    if (file.size > 20 * 1024 * 1024) return alert('Maximum file size is 20 MB.');

    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch('/api/import/preview', { method: 'POST', body: formData });
    const json = await response.json();
    renderPreview(json);
}

async function importData() {
    if (!previewFilePath || !previewIsValid) return alert('Preview a valid Excel file first.');

    const response = await fetch('/api/import/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_path: previewFilePath }),
    });
    const json = await response.json();
    const summary = json.summary || {};

    document.getElementById('importSummary').innerHTML = `
        <h3>${json.status === 'success' ? 'Import Success' : 'Import Failed'}</h3>
        <p>${json.message || '-'}</p>
        <div class="cards">
            ${card('Projects Added', summary.projects_added || summary.new_projects || 0)}
            ${card('Projects Updated', summary.projects_updated || summary.updated_projects || 0)}
            ${card('Activities Added', summary.activities_added || 0)}
            ${card('Documents Added', summary.documents_added || 0)}
            ${card('Dashboard Updated', json.status === 'success' ? 'Yes' : 'No')}
        </div>
        <div class="toolbar" style="margin-top:14px">
            <a class="button primary" href="/">View Dashboard</a>
            <a class="button" href="/projects">View Projects</a>
            <button class="button" type="button" onclick="loadHistory()">Download Import Log</button>
        </div>
    `;

    await loadHistory();
    if (json.status === 'success') {
        await refreshDashboardData();
        showToast('Investment data synchronized successfully.');
    }
}

const dropZone = document.getElementById('dropZone');
dropZone.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropZone.classList.add('dragover');
});
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', (event) => {
    event.preventDefault();
    dropZone.classList.remove('dragover');
    document.getElementById('fileInput').files = event.dataTransfer.files;
    document.getElementById('fileName').textContent = event.dataTransfer.files[0]?.name || 'No file selected.';
});
document.getElementById('fileInput').addEventListener('change', (event) => {
    document.getElementById('fileName').textContent = event.target.files[0]?.name || 'No file selected.';
    document.getElementById('importButton').disabled = true;
});
document.getElementById('previewButton').addEventListener('click', previewFile);
document.getElementById('importButton').addEventListener('click', importData);
document.getElementById('refreshButton').addEventListener('click', refreshDashboardData);

loadHistory();
refreshDashboardData();
</script>
</body>
</html>
