Simple Laravel 12 backend scaffold for Excel-driven investment data imports.

## Stack

- Laravel 12
- PHP 8.3+
- SQLite for development
- MySQL/PostgreSQL ready
- Laravel Excel (`maatwebsite/excel`)
- Laravel Storage
- REST API
- Eloquent ORM

## Install Into A Laravel 12 App

1. Create or open a Laravel 12 project.
2. Install Laravel Excel:

```bash
composer require maatwebsite/excel
```

3. Copy the scaffold folders into the Laravel project root:

```text
app/
database/
routes/
resources/
storage/
```

4. Configure `.env` for SQLite development:

```env
DB_CONNECTION=sqlite
DB_DATABASE=/absolute/path/to/database/database.sqlite
```

5. Run migrations and seeders:

```bash
php artisan migrate --seed
```

6. Put the template file at:

```text
storage/app/templates/Investment_Data_Template.xlsx
```

7. Start the app:

```bash
php artisan serve
```

## Main Workflow

```text
Investment Admin updates Excel
↓
Admin uploads Excel in Import Update
↓
System validates workbook
↓
System imports or updates records
↓
Dashboard refreshes automatically
```

## Notes

- Excel is not the database; it is only an import template.
- `BRD Number` is the unique key for projects.
- `PROJECT_MASTER` updates existing projects or creates new projects.
- `PROJECT_ACTIVITY` always appends new activity rows.
- `PROJECT_DOCUMENT` always appends document metadata rows.
- The workbook contains 5 sheets: `PROJECT_MASTER`, `PROJECT_ACTIVITY`, `PROJECT_DOCUMENT`, `LOOKUP`, `README`.
- Validation errors include sheet name, row number, column name, and message.
- This scaffold intentionally avoids complex CRUD forms, approval workflow, procurement, and issue management.
