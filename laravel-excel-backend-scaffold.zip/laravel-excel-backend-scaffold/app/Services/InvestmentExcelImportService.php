<?php

namespace App\Services;

use App\Imports\RawWorkbookImport;
use App\Models\ImportHistory;
use App\Models\Project;
use App\Models\ProjectActivity;
use App\Models\ProjectDocument;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class InvestmentExcelImportService
{
    private const PROJECT_STATUSES = ['Draft', 'Submitted', 'Approved', 'Running', 'Completed', 'Closed', 'Cancelled'];
    private const ACTIVITY_STATUSES = ['Planned', 'Running', 'Completed', 'Delayed', 'Cancelled'];
    private const DOCUMENT_TYPES = ['BRD', 'Financial Analysis', 'Quotation', 'Contract', 'Progress Report', 'LPJ', 'Final Report', 'Others'];

    private const SHEETS = [
        'PROJECT_MASTER',
        'PROJECT_ACTIVITY',
        'PROJECT_DOCUMENT',
    ];

    private const HEADER_MAP = [
        'BRD Number' => 'brd_number',
        'Project Name' => 'project_name',
        'Division' => 'division',
        'Site' => 'site',
        'Vendor' => 'vendor',
        'PIC' => 'pic',
        'Budget Requested' => 'budget_requested',
        'Budget Approved' => 'budget_approved',
        'Actual Cost' => 'actual_cost',
        'Planned Start Date' => 'planned_start_date',
        'Target Finish Date' => 'target_finish_date',
        'Progress (%)' => 'progress',
        'Status' => 'status',
        'Remarks' => 'remarks',
        'Activity Date' => 'activity_date',
        'Activity' => 'activity_title',
        'Description' => 'description',
        'Notes' => 'notes',
        'Document Type' => 'document_type',
        'Document Name' => 'document_name',
        'Version' => 'version',
        'Upload Date' => 'upload_date',
    ];

    private const DATE_COLUMNS = [
        'planned_start_date',
        'target_finish_date',
        'activity_date',
        'upload_date',
    ];

    public function preview(string $absolutePath): array
    {
        $sheets = $this->readWorkbook($absolutePath);
        $errors = $this->validateSheets($sheets);
        $totalRows = collect($sheets)->flatten(1)->count();
        $changes = $this->changeSummary($sheets, $errors);

        return [
            'summary' => [
                'total_rows' => $totalRows,
                'success_rows' => empty($errors) ? $totalRows : max($totalRows - count($errors), 0),
                'warning_rows' => 0,
                'failed_rows' => count($errors),
                'new_projects' => $changes['new_projects'],
                'updated_projects' => $changes['updated_projects'],
                'activities_added' => $changes['activities_added'],
                'documents_added' => $changes['documents_added'],
                'rows_with_errors' => count($errors),
            ],
            'preview' => $sheets,
            'errors' => $errors,
        ];
    }

    public function process(string $absolutePath, string $importedBy): array
    {
        $preview = $this->preview($absolutePath);

        if (! empty($preview['errors'])) {
            $history = $this->recordHistory($absolutePath, $importedBy, $preview, 'Failed');

            return [
                'status' => 'failed',
                'message' => 'Validation failed. Data was not imported.',
                'history_id' => $history->id,
                'summary' => $preview['summary'],
                'errors' => $preview['errors'],
            ];
        }

        $imported = DB::transaction(function () use ($preview) {
            $counts = [
                'projects_added' => 0,
                'projects_updated' => 0,
                'activities_added' => 0,
                'documents_added' => 0,
            ];

            foreach ($preview['preview']['PROJECT_MASTER'] as $row) {
                $project = Project::withTrashed()->where('brd_number', $row['brd_number'])->first();

                if ($project && $project->trashed()) {
                    $project->restore();
                }

                $payload = [
                    'project_name' => $row['project_name'],
                    'division' => $row['division'],
                    'site' => $row['site'] ?? null,
                    'vendor' => $row['vendor'] ?? null,
                    'pic' => $row['pic'] ?? null,
                    'budget_requested' => $row['budget_requested'] ?? null,
                    'budget_approved' => $row['budget_approved'],
                    'actual_cost' => $row['actual_cost'] ?? null,
                    'planned_start_date' => $row['planned_start_date'] ?? null,
                    'planned_finish_date' => $row['target_finish_date'] ?? null,
                    'progress' => (int) ($row['progress'] ?? 0),
                    'status' => $row['status'],
                    'health_status' => $this->healthStatus($row),
                    'remarks' => $row['remarks'] ?? null,
                ];

                if ($project) {
                    $project->update($payload);
                    $counts['projects_updated']++;
                } else {
                    Project::create(['brd_number' => $row['brd_number'], ...$payload]);
                    $counts['projects_added']++;
                }
            }

            foreach ($preview['preview']['PROJECT_ACTIVITY'] as $row) {
                $project = Project::where('brd_number', $row['brd_number'])->firstOrFail();

                ProjectActivity::create([
                    'project_id' => $project->id,
                    'brd_number' => $row['brd_number'],
                    'activity_date' => $row['activity_date'],
                    'activity_type' => $row['activity_title'],
                    'activity_title' => $row['activity_title'],
                    'description' => $row['description'] ?? null,
                    'pic' => $row['pic'] ?? null,
                    'progress' => $row['progress'] ?? null,
                    'status' => $row['status'],
                    'notes' => $row['notes'] ?? null,
                ]);

                $counts['activities_added']++;
            }

            foreach ($preview['preview']['PROJECT_DOCUMENT'] as $row) {
                $project = Project::where('brd_number', $row['brd_number'])->firstOrFail();

                ProjectDocument::create([
                    'project_id' => $project->id,
                    'brd_number' => $row['brd_number'],
                    'document_type' => $row['document_type'],
                    'document_name' => $row['document_name'],
                    'version' => $row['version'] ?? null,
                    'upload_date' => $row['upload_date'] ?? null,
                    'remarks' => $row['remarks'] ?? null,
                ]);

                $counts['documents_added']++;
            }

            return $counts;
        });

        $preview['summary'] = [
            ...$preview['summary'],
            ...$imported,
            'new_projects' => $imported['projects_added'],
            'updated_projects' => $imported['projects_updated'],
        ];

        $history = $this->recordHistory($absolutePath, $importedBy, $preview, 'Success');

        return [
            'status' => 'success',
            'message' => 'Investment data synchronized successfully.',
            'history_id' => $history->id,
            'summary' => $preview['summary'],
        ];
    }

    private function readWorkbook(string $absolutePath): array
    {
        $rawSheets = Excel::toArray(new RawWorkbookImport(), $absolutePath);
        $result = array_fill_keys(self::SHEETS, []);

        foreach (self::SHEETS as $index => $sheetName) {
            $rows = $rawSheets[$index] ?? [];
            $headers = array_map(fn ($value) => self::HEADER_MAP[trim((string) $value)] ?? trim((string) $value), $rows[0] ?? []);

            foreach (array_slice($rows, 1) as $rowIndex => $row) {
                if ($this->isBlankRow($row)) {
                    continue;
                }

                $assoc = [];
                foreach ($headers as $columnIndex => $header) {
                    if ($header !== '') {
                        $assoc[$header] = $this->normalizeValue($row[$columnIndex] ?? null, $header);
                    }
                }
                $assoc['_row'] = $rowIndex + 2;
                $result[$sheetName][] = $assoc;
            }
        }

        return $result;
    }

    private function validateSheets(array $sheets): array
    {
        $errors = [];
        $projectBrds = collect($sheets['PROJECT_MASTER'])->pluck('brd_number')->filter()->map(fn ($value) => (string) $value)->values();
        $existingBrds = Project::query()->pluck('brd_number')->map(fn ($value) => (string) $value);
        $knownBrds = $projectBrds->merge($existingBrds)->unique()->values()->all();

        foreach ($sheets['PROJECT_MASTER'] as $row) {
            foreach (['brd_number', 'project_name', 'division', 'pic', 'budget_approved', 'planned_start_date', 'target_finish_date', 'progress', 'status'] as $column) {
                $this->required($errors, 'PROJECT_MASTER', $row, $column);
            }

            $this->numeric($errors, 'PROJECT_MASTER', $row, 'budget_requested');
            $this->numeric($errors, 'PROJECT_MASTER', $row, 'budget_approved');
            $this->numeric($errors, 'PROJECT_MASTER', $row, 'actual_cost');
            $this->progress($errors, 'PROJECT_MASTER', $row);
            $this->date($errors, 'PROJECT_MASTER', $row, 'planned_start_date');
            $this->date($errors, 'PROJECT_MASTER', $row, 'target_finish_date');
            $this->inList($errors, 'PROJECT_MASTER', $row, 'status', self::PROJECT_STATUSES);
        }

        foreach ($sheets['PROJECT_ACTIVITY'] as $row) {
            foreach (['activity_date', 'brd_number', 'project_name', 'activity_title', 'status'] as $column) {
                $this->required($errors, 'PROJECT_ACTIVITY', $row, $column);
            }

            $this->brdExists($errors, 'PROJECT_ACTIVITY', $row, $knownBrds);
            $this->date($errors, 'PROJECT_ACTIVITY', $row, 'activity_date');
            $this->progress($errors, 'PROJECT_ACTIVITY', $row);
            $this->inList($errors, 'PROJECT_ACTIVITY', $row, 'status', self::ACTIVITY_STATUSES);
        }

        foreach ($sheets['PROJECT_DOCUMENT'] as $row) {
            foreach (['brd_number', 'project_name', 'document_type', 'document_name'] as $column) {
                $this->required($errors, 'PROJECT_DOCUMENT', $row, $column);
            }

            $this->brdExists($errors, 'PROJECT_DOCUMENT', $row, $knownBrds);
            $this->date($errors, 'PROJECT_DOCUMENT', $row, 'upload_date');
            $this->inList($errors, 'PROJECT_DOCUMENT', $row, 'document_type', self::DOCUMENT_TYPES);
        }

        return $errors;
    }

    private function changeSummary(array $sheets, array $errors): array
    {
        $existingBrds = Project::query()->pluck('brd_number')->map(fn ($value) => (string) $value)->all();
        $projectBrds = collect($sheets['PROJECT_MASTER'])->pluck('brd_number')->filter()->map(fn ($value) => (string) $value)->unique();

        return [
            'new_projects' => $projectBrds->reject(fn ($brd) => in_array($brd, $existingBrds, true))->count(),
            'updated_projects' => $projectBrds->filter(fn ($brd) => in_array($brd, $existingBrds, true))->count(),
            'activities_added' => empty($errors) ? count($sheets['PROJECT_ACTIVITY']) : 0,
            'documents_added' => empty($errors) ? count($sheets['PROJECT_DOCUMENT']) : 0,
        ];
    }

    private function required(array &$errors, string $sheet, array $row, string $column): void
    {
        if (($row[$column] ?? '') === '') {
            $this->error($errors, $sheet, $row, $column, $this->label($column).' is required.');
        }
    }

    private function numeric(array &$errors, string $sheet, array $row, string $column): void
    {
        if (($row[$column] ?? '') !== '' && ! is_numeric($row[$column])) {
            $this->error($errors, $sheet, $row, $column, $this->label($column).' must be numeric.');
        }
    }

    private function progress(array &$errors, string $sheet, array $row): void
    {
        if (($row['progress'] ?? '') !== '' && (! is_numeric($row['progress']) || $row['progress'] < 0 || $row['progress'] > 100)) {
            $this->error($errors, $sheet, $row, 'progress', 'Progress must be between 0 and 100.');
        }
    }

    private function date(array &$errors, string $sheet, array $row, string $column): void
    {
        if (($row[$column] ?? '') === '') {
            return;
        }

        try {
            Carbon::parse($row[$column]);
        } catch (\Throwable) {
            $this->error($errors, $sheet, $row, $column, $this->label($column).' must be a valid date.');
        }
    }

    private function inList(array &$errors, string $sheet, array $row, string $column, array $allowed): void
    {
        if (($row[$column] ?? '') !== '' && ! in_array($row[$column], $allowed, true)) {
            $this->error($errors, $sheet, $row, $column, $this->label($column).' must be one of: '.implode(', ', $allowed).'.');
        }
    }

    private function brdExists(array &$errors, string $sheet, array $row, array $knownBrds): void
    {
        if (($row['brd_number'] ?? '') !== '' && ! in_array((string) $row['brd_number'], $knownBrds, true)) {
            $this->error($errors, $sheet, $row, 'brd_number', 'BRD Number must exist in PROJECT_MASTER or in current project data.');
        }
    }

    private function error(array &$errors, string $sheet, array $row, string $column, string $message): void
    {
        $errors[] = [
            'sheet' => $sheet,
            'row' => $row['_row'] ?? null,
            'column' => $this->label($column),
            'message' => $message,
        ];
    }

    private function normalizeValue(mixed $value, string $header): mixed
    {
        if ($value === null) {
            return '';
        }

        if (in_array($header, self::DATE_COLUMNS, true) && is_numeric($value)) {
            return Carbon::create(1899, 12, 30)->addDays((int) $value)->toDateString();
        }

        if (in_array($header, self::DATE_COLUMNS, true) && $value instanceof \DateTimeInterface) {
            return Carbon::instance($value)->toDateString();
        }

        if (is_string($value)) {
            $trimmed = trim($value);

            if (in_array($header, self::DATE_COLUMNS, true) && preg_match('/^\d{1,2}\/\d{1,2}\/\d{4}$/', $trimmed)) {
                try {
                    return Carbon::createFromFormat('d/m/Y', $trimmed)->toDateString();
                } catch (\Throwable) {
                    return $trimmed;
                }
            }

            return $trimmed;
        }

        return $value;
    }

    private function isBlankRow(array $row): bool
    {
        return collect($row)->every(fn ($value) => trim((string) $value) === '');
    }

    private function healthStatus(array $row): string
    {
        if (($row['status'] ?? '') === 'Completed') {
            return 'Healthy';
        }

        if ((int) ($row['progress'] ?? 0) < 50) {
            return 'Need Attention';
        }

        return 'Healthy';
    }

    private function recordHistory(string $absolutePath, string $importedBy, array $preview, string $status): ImportHistory
    {
        $errorFilePath = null;
        if (! empty($preview['errors'])) {
            $errorFilePath = 'imports/errors/'.now()->format('Ymd_His').'_errors.json';
            Storage::disk('local')->put($errorFilePath, json_encode($preview['errors'], JSON_PRETTY_PRINT));
        }

        return ImportHistory::create([
            'file_name' => basename($absolutePath),
            'imported_by' => $importedBy,
            'import_date' => now(),
            'total_rows' => $preview['summary']['total_rows'],
            'success_rows' => $status === 'Success' ? $preview['summary']['total_rows'] : 0,
            'failed_rows' => count($preview['errors']),
            'projects_added' => $preview['summary']['projects_added'] ?? $preview['summary']['new_projects'] ?? 0,
            'projects_updated' => $preview['summary']['projects_updated'] ?? $preview['summary']['updated_projects'] ?? 0,
            'activities_added' => $preview['summary']['activities_added'] ?? 0,
            'documents_added' => $preview['summary']['documents_added'] ?? 0,
            'status' => $status,
            'error_file_path' => $errorFilePath,
        ]);
    }

    private function label(string $column): string
    {
        return match ($column) {
            'brd_number' => 'BRD Number',
            'project_name' => 'Project Name',
            'budget_requested' => 'Budget Requested',
            'budget_approved' => 'Budget Approved',
            'actual_cost' => 'Actual Cost',
            'planned_start_date' => 'Planned Start Date',
            'target_finish_date' => 'Target Finish Date',
            'activity_date' => 'Activity Date',
            'activity_title' => 'Activity',
            'document_type' => 'Document Type',
            'document_name' => 'Document Name',
            'upload_date' => 'Upload Date',
            default => str($column)->replace('_', ' ')->title()->toString(),
        };
    }
}
