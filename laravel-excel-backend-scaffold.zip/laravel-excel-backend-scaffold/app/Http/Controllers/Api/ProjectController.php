<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\JsonResponse;

class ProjectController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json([
            'data' => Project::query()
                ->withCount(['activities', 'documents'])
                ->latest()
                ->paginate(25),
        ]);
    }

    public function show(Project $project): JsonResponse
    {
        return response()->json([
            'data' => $project->load([
                'activities' => fn ($query) => $query->latest('activity_date'),
                'documents' => fn ($query) => $query->latest('upload_date'),
            ]),
        ]);
    }
}
