<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ProjectActivity;
use Illuminate\Http\JsonResponse;

class AnalyticsController extends Controller
{
    public function summary(): JsonResponse
    {
        $projects = Project::query()->withCount(['activities', 'documents'])->get();
        $totalApproved = (float) $projects->sum('budget_approved');
        $totalActual = (float) $projects->sum('actual_cost');

        return response()->json([
            'summary' => [
                'total_investment' => $totalApproved,
                'actual_cost' => $totalActual,
                'budget_variance' => $totalApproved - $totalActual,
                'average_progress' => $projects->count() ? round($projects->avg('progress')) : 0,
                'total_activities' => ProjectActivity::query()->count(),
            ],
            'ranking' => [
                'highest_investment' => $projects->sortByDesc('budget_approved')->values()->take(10),
                'budget_utilization' => $projects->sortByDesc(fn ($project) => ((float) $project->actual_cost) / max((float) $project->budget_approved, 1))->values()->take(10),
                'most_active_projects' => $projects->sortByDesc('activities_count')->values()->take(10),
            ],
            'charts' => [
                'status_distribution' => $projects->groupBy('status')->map(fn ($rows, $status) => ['label' => $status ?: 'Unassigned', 'value' => $rows->count()])->values(),
                'division_investment' => $projects->groupBy('division')->map(fn ($rows, $division) => ['label' => $division ?: 'Unassigned', 'value' => (float) $rows->sum('budget_approved')])->values(),
                'site_investment' => $projects->groupBy('site')->map(fn ($rows, $site) => ['label' => $site ?: 'Unassigned', 'value' => (float) $rows->sum('budget_approved')])->values(),
            ],
        ]);
    }
}
