<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ImportHistory;
use App\Services\InvestmentExcelImportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ImportUpdateController extends Controller
{
    public function __construct(private readonly InvestmentExcelImportService $importService)
    {
    }

    public function template()
    {
        $path = 'templates/Investment_Data_Template.xlsx';

        abort_unless(Storage::disk('local')->exists($path), 404, 'Excel template not found.');

        return Storage::disk('local')->download($path, 'Investment_Data_Template.xlsx');
    }

    public function preview(Request $request): JsonResponse
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx', 'max:20480'],
        ]);

        $path = $request->file('file')->storeAs(
            'imports/previews',
            now()->format('Ymd_His').'_'.str($request->file('file')->getClientOriginalName())->replace(' ', '_')->toString()
        );
        $result = $this->importService->preview(Storage::path($path));

        return response()->json([
            'file_path' => $path,
            'valid' => empty($result['errors']),
            ...$result,
        ]);
    }

    public function process(Request $request): JsonResponse
    {
        $request->validate([
            'file_path' => ['required', 'string'],
        ]);

        $filePath = (string) $request->string('file_path');

        abort_unless(Storage::disk('local')->exists($filePath), 404, 'Uploaded preview file not found.');

        $result = $this->importService->process(Storage::path($filePath), $request->user()?->name ?? 'Investment Admin');

        return response()->json($result);
    }

    public function history(): JsonResponse
    {
        return response()->json([
            'data' => ImportHistory::query()->latest('import_date')->paginate(20),
            'latest' => ImportHistory::query()->latest('import_date')->first(),
        ]);
    }
}
