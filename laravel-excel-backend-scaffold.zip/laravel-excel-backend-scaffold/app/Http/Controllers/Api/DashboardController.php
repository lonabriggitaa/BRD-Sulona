<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ImportHistory;
use App\Models\Project;
use App\Models\ProjectActivity;
use App\Models\ProjectDocument;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function summary(): JsonResponse
    {
        $projects = Project::query()
            ->with(['activities' => fn ($query) => $query->latest('activity_date'), 'documents'])
            ->latest()
            ->get();

        $totalApproved = (float) $projects->sum('budget_approved');
        $totalActual = (float) $projects->sum('actual_cost');
        $completed = $projects->where('status', 'Completed')->count();
        $running = $projects->where('status', 'Running')->count();
        $averageProgress = $projects->count() > 0 ? round($projects->avg('progress')) : 0;

        return response()->json([
            'kpis' => [
                'total_projects' => $projects->count(),
                'total_investment' => $totalApproved,
                'actual_cost' => $totalActual,
                'budget_variance' => $totalApproved - $totalActual,
                'budget_utilization' => $totalApproved > 0 ? round(($totalActual / $totalApproved) * 100) : 0,
                'average_progress' => $averageProgress,
                'completed_projects' => $completed,
                'running_projects' => $running,
                'activity_count' => ProjectActivity::query()->count(),
                'document_count' => ProjectDocument::query()->count(),
            ],
            'status_distribution' => $this->groupCount($projects, 'status'),
            'division_investment' => $projects->groupBy('division')
                ->map(fn ($rows, $division) => ['label' => $division ?: 'Unassigned', 'value' => (float) $rows->sum('budget_approved')])
                ->values(),
            'site_investment' => $projects->groupBy('site')
                ->map(fn ($rows, $site) => ['label' => $site ?: 'Unassigned', 'value' => (float) $rows->sum('budget_approved')])
                ->values(),
            'recent_activities' => ProjectActivity::query()
                ->with('project:id,brd_number,project_name')
                ->latest('activity_date')
                ->limit(10)
                ->get(),
            'recent_documents' => ProjectDocument::query()
                ->with('project:id,brd_number,project_name')
                ->latest('upload_date')
                ->limit(10)
                ->get(),
            'latest_import' => ImportHistory::query()->latest('import_date')->first(),
            'projects' => $projects,
        ]);
    }

    private function groupCount($rows, string $column)
    {
        return $rows->groupBy($column)
            ->map(fn ($items, $label) => ['label' => $label ?: 'Unassigned', 'value' => $items->count()])
            ->values();
    }
}
