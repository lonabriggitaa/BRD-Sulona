<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ProjectActivity;
use App\Models\ProjectDocument;
use Illuminate\Http\JsonResponse;

class ProjectWorkspaceController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json([
            'projects' => Project::query()
                ->with(['activities' => fn ($query) => $query->latest('activity_date'), 'documents' => fn ($query) => $query->latest('upload_date')])
                ->latest()
                ->get(),
            'activity_timeline' => ProjectActivity::query()
                ->with('project:id,brd_number,project_name')
                ->latest('activity_date')
                ->limit(50)
                ->get(),
            'documents' => ProjectDocument::query()
                ->with('project:id,brd_number,project_name')
                ->latest('upload_date')
                ->limit(50)
                ->get(),
        ]);
    }
}
