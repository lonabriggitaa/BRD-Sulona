<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImportHistory extends Model
{
    protected $fillable = [
        'file_name',
        'imported_by',
        'import_date',
        'total_rows',
        'success_rows',
        'failed_rows',
        'projects_added',
        'projects_updated',
        'activities_added',
        'documents_added',
        'status',
        'error_file_path',
    ];

    protected $casts = [
        'import_date' => 'datetime',
    ];
}
