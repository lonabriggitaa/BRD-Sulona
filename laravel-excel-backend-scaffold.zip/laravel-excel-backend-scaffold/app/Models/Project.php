<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Project extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'brd_number',
        'project_name',
        'division',
        'department',
        'site',
        'category',
        'priority',
        'vendor',
        'pic',
        'budget_requested',
        'budget_approved',
        'actual_cost',
        'planned_start_date',
        'planned_finish_date',
        'actual_start_date',
        'actual_finish_date',
        'progress',
        'status',
        'health_status',
        'remarks',
    ];

    protected $casts = [
        'budget_requested' => 'decimal:2',
        'budget_approved' => 'decimal:2',
        'actual_cost' => 'decimal:2',
        'planned_start_date' => 'date',
        'planned_finish_date' => 'date',
        'actual_start_date' => 'date',
        'actual_finish_date' => 'date',
        'progress' => 'integer',
    ];

    public function activities(): HasMany
    {
        return $this->hasMany(ProjectActivity::class);
    }

    public function documents(): HasMany
    {
        return $this->hasMany(ProjectDocument::class);
    }
}
