<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProjectActivity extends Model
{
    protected $fillable = [
        'project_id',
        'brd_number',
        'activity_date',
        'activity_type',
        'activity_title',
        'description',
        'pic',
        'progress',
        'status',
        'notes',
    ];

    protected $casts = [
        'activity_date' => 'date',
        'progress' => 'integer',
    ];

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }
}
