<?php

use Illuminate\Support\Facades\Route;

Route::view('/import-update', 'import-update')->name('import-update');
