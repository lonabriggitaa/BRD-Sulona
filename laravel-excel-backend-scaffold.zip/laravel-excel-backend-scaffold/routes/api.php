<?php

use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\ImportUpdateController;
use App\Http\Controllers\Api\AnalyticsController;
use App\Http\Controllers\Api\ProjectController;
use App\Http\Controllers\Api\ProjectWorkspaceController;
use Illuminate\Support\Facades\Route;

Route::prefix('import')->group(function () {
    Route::get('/template', [ImportUpdateController::class, 'template']);
    Route::post('/preview', [ImportUpdateController::class, 'preview']);
    Route::post('/process', [ImportUpdateController::class, 'process']);
    Route::get('/history', [ImportUpdateController::class, 'history']);
});

Route::get('/dashboard/summary', [DashboardController::class, 'summary']);
Route::get('/analytics/summary', [AnalyticsController::class, 'summary']);
Route::get('/project-workspace', [ProjectWorkspaceController::class, 'index']);
Route::get('/projects', [ProjectController::class, 'index']);
Route::get('/projects/{project}', [ProjectController::class, 'show']);
